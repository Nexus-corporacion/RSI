/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useRef } from 'react';
import {
  Activity,
  AlertTriangle,
  Zap,
  TrendingUp,
  TrendingDown,
  Clock,
  Gauge,
  SlidersHorizontal,
  FolderSync,
  Layers,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { analyzeIndicators, Candle, IndicatorResult } from './utils/indicators';
import { getUSDTFuturesTickers, getSymbolCandles, BitgetTickerData } from './utils/bitgetApi';
import ScannerChart from './components/ScannerChart';
import AlertsPanel, { AlertEntry, synths } from './components/AlertsPanel';

// Normalized view state
interface MarketAsset {
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  fundingRate: number;
  openInterest: number;
  rsi: number;
  score: number;
  trend: 'Alcista' | 'Bajista' | 'Neutral';
  lastScanned: number;
  signals: string[];
  analysis?: IndicatorResult;
}

export default function App() {
  // Configurable bounds - strict default 15 and 85
  const [rsiOverbought, setRsiOverbought] = useState<number>(85);
  const [rsiOversold, setRsiOversold] = useState<number>(15);
  const [activeTimeframe, setActiveTimeframe] = useState<'5m' | '15m' | '1h' | '4h'>('15m');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Scanned Assets State
  const [assets, setAssets] = useState<Record<string, MarketAsset>>({});
  const [tickerList, setTickerList] = useState<BitgetTickerData[]>([]);
  const [activeSymbol, setActiveSymbol] = useState<string>('BTCUSDT');
  const [activeCandles, setActiveCandles] = useState<Candle[]>([]);
  const [activeAnalysis, setActiveAnalysis] = useState<IndicatorResult | null>(null);
  
  // Multi Timeframe states (for Selected asset)
  const [mtfData, setMtfData] = useState<Record<string, { close: number; rsi: number; trend: string }>>({});

  // App metrics
  const [isScanning, setIsScanning] = useState(true);
  const [scanSpeed, setScanSpeed] = useState<number>(0); // scans per min
  const [apiStatus, setApiStatus] = useState<'ONLINE' | 'FALLBACK_SIM'>('ONLINE');
  const [alerts, setAlerts] = useState<AlertEntry[]>([]);
  const [unseenAlertsCount, setUnseenAlertsCount] = useState(0);

  // Queue background indexes
  const scanIndexRef = useRef<number>(0);
  const backgroundTimerRef = useRef<NodeJS.Timeout | null>(null);
  const tickersTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Stats
  const [stats, setStats] = useState({
    analyzedCount: 0,
    activesSignalsCount: 0,
    longPct: 50,
    shortPct: 50,
    topAssets: [] as { symbol: string; score: number; signal: string }[],
  });

  // Load All Assets initially
  const loadInitialTickers = async () => {
    try {
      const data = await getUSDTFuturesTickers();
      setTickerList(data);
      setApiStatus('ONLINE');
      
      // Initialize states to prevent blank displays
      const initialAssets: Record<string, MarketAsset> = {};
      data.forEach((t) => {
        initialAssets[t.symbol] = {
          symbol: t.symbol,
          price: t.price,
          change24h: t.change24h,
          high24h: t.high24h,
          low24h: t.low24h,
          volume24h: t.volume24h,
          fundingRate: t.fundingRate,
          openInterest: t.openInterest,
          rsi: 50,
          score: 0,
          trend: 'Alcista',
          lastScanned: 0,
          signals: [],
        };
      });

      setAssets((prev) => {
        const merged = { ...initialAssets };
        Object.keys(prev).forEach((k) => {
          if (merged[k]) {
            merged[k] = {
              ...merged[k],
              rsi: prev[k].rsi,
              score: prev[k].score,
              trend: prev[k].trend,
              lastScanned: prev[k].lastScanned,
              signals: prev[k].signals,
              analysis: prev[k].analysis,
            };
          }
        });
        return merged;
      });

      // Quick pre-scanning of popular coins on first load so there are instant extreme detections!
      const topPopular = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'DOGEUSDT', 'PEPEUSDT', 'XRPUSDT', 'AVAXUSDT', 'NEARUSDT', 'SUIUSDT', 'LTCUSDT', 'LINKUSDT', 'ADAUSDT'];
      setTimeout(() => {
        topPopular.forEach(async (symbol) => {
          const matched = data.find((x) => x.symbol === symbol);
          if (matched) {
            try {
              const candles = await getSymbolCandles(symbol, activeTimeframe, 85);
              if (candles && candles.length > 5) {
                const analysis = analyzeIndicators(candles, rsiOverbought, rsiOversold, {
                  fundingRate: matched.fundingRate,
                  openInterestChange: 0.04
                });
                const latestRsi = analysis.rsi[analysis.rsi.length - 1];
                setAssets((prev) => {
                  const original = prev[symbol] || {
                    symbol,
                    price: matched.price,
                    change24h: matched.change24h,
                    high24h: matched.high24h,
                    low24h: matched.low24h,
                    volume24h: matched.volume24h,
                    fundingRate: matched.fundingRate,
                    openInterest: matched.openInterest,
                  };
                  return {
                    ...prev,
                    [symbol]: {
                      ...original,
                      rsi: latestRsi,
                      score: analysis.currentScore,
                      trend: (() => {
                        const lState = analysis.trendLine[analysis.trendLine.length - 1]?.state;
                        return lState === 'bullish' ? 'Alcista' : lState === 'bearish' ? 'Bajista' : 'Neutral';
                      })(),
                      lastScanned: Date.now(),
                      signals: analysis.signals,
                      analysis,
                    },
                  };
                });
              }
            } catch (err) { }
          }
        });
      }, 100);
    } catch (err) {
      console.error('API Error initialization', err);
      setApiStatus('FALLBACK_SIM');
    }
  };

  // Sequence background scan list
  const scanBackgroundQueue = async () => {
    if (tickerList.length === 0) return;
    
    // Pick the next ticker to evaluate
    const index = scanIndexRef.current % tickerList.length;
    const item = tickerList[index];
    scanIndexRef.current++;

    try {
      const candles = await getSymbolCandles(item.symbol, activeTimeframe, 85);
      if (candles && candles.length > 4) {
        const analysis = analyzeIndicators(candles, rsiOverbought, rsiOversold, {
          fundingRate: item.fundingRate,
          openInterestChange: 0.04
        });

        const latestRsi = analysis.rsi[analysis.rsi.length - 1];
        const latestScore = analysis.currentScore;

        setAssets((prev) => {
          const original = prev[item.symbol] || {
            symbol: item.symbol,
            price: item.price,
            change24h: item.change24h,
            high24h: item.high24h,
            low24h: item.low24h,
            volume24h: item.volume24h,
            fundingRate: item.fundingRate,
            openInterest: item.openInterest,
          };
          return {
            ...prev,
            [item.symbol]: {
              ...original,
              rsi: latestRsi,
              score: latestScore,
              trend: (() => {
                const lState = analysis.trendLine[analysis.trendLine.length - 1]?.state;
                return lState === 'bullish' ? 'Alcista' : lState === 'bearish' ? 'Bajista' : 'Neutral';
              })(),
              lastScanned: Date.now(),
              signals: analysis.signals,
              analysis,
            },
          };
        });

        checkSoundAndLogAlert(item.symbol, candles[candles.length - 1].close, latestRsi, latestScore, analysis.signals);
      }
    } catch (err) {
      console.warn(`Skip background scan for ${item.symbol}. Server throttled.`);
    }
  };

  /**
   * Scans current selected symbol for detail chart and MTF data
   */
  const scanSelectedSymbol = async (symbol: string) => {
    try {
      // 1. Fetch candles for current active timeframe
      const candles = await getSymbolCandles(symbol, activeTimeframe, 85);
      if (candles && candles.length > 0) {
        setActiveCandles(candles);
        const analysis = analyzeIndicators(candles, rsiOverbought, rsiOversold, {
          fundingRate: tickerList.find((t) => t.symbol === symbol)?.fundingRate || 0.0001,
          openInterestChange: 0.04
        });
        setActiveAnalysis(analysis);
      }

      // 2. Fetch Multi Timeframes indices for MTF alignment gauge
      const timeframes: ('5m' | '15m' | '1h' | '4h')[] = ['5m', '15m', '1h', '4h'];
      const results: Record<string, { close: number; rsi: number; trend: string }> = {};

      for (const tf of timeframes) {
        try {
          const c = await getSymbolCandles(symbol, tf, 40);
          if (c && c.length > 5) {
            const an = analyzeIndicators(c, rsiOverbought, rsiOversold);
            results[tf] = {
              close: c[c.length - 1].close,
              rsi: an.rsi[an.rsi.length - 1],
              trend: (() => {
                const lState = an.trendLine[an.trendLine.length - 1]?.state;
                return lState === 'bullish' ? 'Alcista' : lState === 'bearish' ? 'Bajista' : 'Neutral';
              })(),
            };
          }
        } catch (e) {
          // fallback placeholder
          results[tf] = { close: 0, rsi: 50, trend: 'Alcista' };
        }
      }
      setMtfData(results);
    } catch (err) {
      console.error('Failed scanning active asset details', err);
    }
  };

  /**
   * Analyzes signals and triggers sounds and records logs
   */
  const checkSoundAndLogAlert = (
    symbol: string,
    price: number,
    rsi: number,
    score: number,
    signals: string[]
  ) => {
    const isOversold = rsi <= rsiOversold;
    const isOverbought = rsi >= rsiOverbought;
    const isCritical = score >= 90;

    let triggerType: 'LONG' | 'SHORT' | 'SNIPER_LONG' | 'SNIPER_SHORT' | null = null;
    let message = '';

    if (isCritical) {
      triggerType = rsi <= 20 ? 'SNIPER_LONG' : 'SNIPER_SHORT';
      message = rsi <= 20 ? 'Sniper LONG Extremo' : 'Sniper SHORT Extremo';
    } else if (isOversold) {
      triggerType = 'LONG';
      message = 'Soporte Long Confirmado';
    } else if (isOverbought) {
      triggerType = 'SHORT';
      message = 'Resistencia Short Confirmada';
    }

    if (triggerType) {
      // Avoid duplicated alert for same asset within 60 seconds
      setAlerts((prev) => {
        const recentDuplicate = prev.find((a) => a.symbol === symbol && Date.now() - a.time < 60000);
        if (recentDuplicate) return prev;

        // Perform sound synthesis smoothly
        if (isCritical) {
          synths.playCritica();
        } else if (isOversold) {
          synths.playSuave();
        } else if (isOverbought) {
          synths.playFuerte();
        }

        // Display browser native notification if permitted
        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification(`Quant Scanner: ${symbol}`, {
              body: `${message} en RSI ${rsi.toFixed(2)} - Score: ${score}/100`,
              icon: '/favicon.ico',
            });
          } catch (e) {
            console.warn('Browser notification failed', e);
          }
        }

        return [
          {
            id: `${symbol}_${Date.now()}`,
            time: Date.now(),
            symbol,
            price,
            rsi,
            score,
            type: triggerType!,
            msg: message,
          },
          ...prev,
        ].slice(0, 50); // limit logs to latest 50 entries
      });
    }
  };

  // Mount, tickers fetching loops & background interval logic
  useEffect(() => {
    loadInitialTickers();

    // Redraw Tickers metadata every 45s
    tickersTimerRef.current = setInterval(() => {
      loadInitialTickers();
    }, 45000);

    return () => {
      if (tickersTimerRef.current) clearInterval(tickersTimerRef.current);
    };
  }, []);

  // Manage Background scan frequency
  useEffect(() => {
    if (backgroundTimerRef.current) clearInterval(backgroundTimerRef.current);

    if (isScanning && tickerList.length > 0) {
      backgroundTimerRef.current = setInterval(() => {
        scanBackgroundQueue();
      }, 800); // Fast sequential scans utilizing high rate limits
    }

    return () => {
      if (backgroundTimerRef.current) clearInterval(backgroundTimerRef.current);
    };
  }, [isScanning, tickerList, activeTimeframe, rsiOverbought, rsiOversold]);

  // Priority fetch on symbol change
  useEffect(() => {
    scanSelectedSymbol(activeSymbol);
  }, [activeSymbol, activeTimeframe, rsiOverbought, rsiOversold]);

  // Aggregate stats periodically
  useEffect(() => {
    const list = Object.values(assets) as MarketAsset[];
    if (list.length === 0) return;

    const analyzed = list.filter((a) => a.lastScanned > 0);
    const activeS = list.filter((a) => a.rsi <= rsiOversold || a.rsi >= rsiOverbought);
    
    // Sort and get top assets based on indicator Scores
    const ranked = [...list]
      .filter((a) => a.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
      .map((a) => ({
        symbol: a.symbol,
        score: a.score,
        signal: a.rsi <= 20 ? 'BUY S' : a.rsi >= 80 ? 'SELL S' : 'VIG',
      }));

    // Long vs Short Ratio calculate
    let longs = 0;
    let shorts = 0;
    analyzed.forEach((a) => {
      if (a.rsi <= 50) longs++;
      else shorts++;
    });
    const total = longs + shorts || 1;

    setStats({
      analyzedCount: analyzed.length,
      activesSignalsCount: activeS.length,
      longPct: Math.round((longs / total) * 100),
      shortPct: Math.round((shorts / total) * 100),
      topAssets: ranked,
    });
    
    // Estimate scans speed
    setScanSpeed(Math.round((analyzed.length / 5) * 60));
  }, [assets]);

  // List of symbols formatted for Sidebar - STRICTLY displaying extreme coins <= rsiOversold or >= rsiOverbought, up to 5 Long and 5 Short to prevent clutter!
  const sortedRanking = (() => {
    const all = Object.values(assets) as MarketAsset[];
    if (searchQuery.trim()) {
      return all
        .filter((a) => a.symbol.toLowerCase().includes(searchQuery.toLowerCase()))
        .sort((a, b) => b.score - a.score);
    }
    
    const longs = all
      .filter((a) => a.lastScanned > 0 && a.rsi <= rsiOversold)
      .sort((a, b) => b.score - a.score || a.rsi - b.rsi)
      .slice(0, 5);

    const shorts = all
      .filter((a) => a.lastScanned > 0 && a.rsi >= rsiOverbought)
      .sort((a, b) => b.score - a.score || b.rsi - a.rsi)
      .slice(0, 5);

    return [...longs, ...shorts];
  })();

  // Consensus overall calculations
  const calculateTotalConsensus = () => {
    const listMtf = Object.values(mtfData) as { close: number; rsi: number; trend: string }[];
    const count = listMtf.length;
    if (count === 0) return { label: 'ZONA DE TRANSICIÓN', color: 'text-slate-400 border-slate-800 bg-slate-900/10' };
    
    let bulls = 0;
    let bears = 0;
    listMtf.forEach((m) => {
      if (m.trend === 'Alcista') bulls++;
      else bears++;
    });

    if (bulls >= 3) return { label: 'FUERTE ALCISTA', color: 'text-emerald-400 border-emerald-800/60 bg-emerald-950/20 shadow-[0_0_15px_rgba(16,185,129,0.15)] animate-pulse' };
    if (bears >= 3) return { label: 'FUERTE BAJISTA', color: 'text-rose-400 border-rose-800/60 bg-rose-950/20 shadow-[0_0_15px_rgba(244,63,94,0.15)] animate-pulse' };
    return { label: 'VÓRTICE NEUTRAL', color: 'text-amber-400 border-amber-800/40 bg-amber-950/10' };
  };
  const consensusObj = calculateTotalConsensus();

  return (
    <div id="scanner-cyberpunk-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-900 overflow-x-hidden relative">
      
      {/* Decorative ambient background glowing mesh lines */}
      <span className="absolute top-0 left-1/4 w-[1px] h-[500px] bg-gradient-to-b from-blue-500/10 to-transparent pointer-events-none"></span>
      <span className="absolute top-0 right-1/4 w-[1px] h-[500px] bg-gradient-to-b from-purple-500/10 to-transparent pointer-events-none"></span>      {/* HEADER SECTION */}
      <header className="border-b border-slate-900 bg-slate-950/95 sticky top-0 z-30 backdrop-blur-md px-4 py-3 sm:px-6">
        <div className="max-w-full xl:px-4 mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-y-3">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <span className="absolute -inset-1 rounded-lg bg-gradient-to-r from-cyan-400 to-purple-600 blur opacity-60 animate-pulse"></span>
              <div className="relative bg-slate-950 p-1.5 rounded-lg border border-cyan-500/85">
                <Activity className="text-cyan-400 animate-spin" size={16} />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-450">
                  FUTURES QUANT SCANNER v.0
                </h1>
              </div>
            </div>
          </div>

          {/* Configuration Parameters & Config Panel */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Limit Configuration Overbought */}
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-850 px-2.5 py-1 rounded-xl">
              <span className="text-xs font-mono text-rose-400 uppercase tracking-tight font-bold">RSI Alto:</span>
              <input
                id="input-ob-rsi"
                type="number"
                min="70"
                max="95"
                value={rsiOverbought}
                onChange={(e) => setRsiOverbought(Math.max(70, Math.min(95, parseInt(e.target.value) || 85)))}
                className="w-12 text-center bg-slate-950 border border-slate-800 text-rose-400 font-extrabold font-mono text-xs p-0.5 rounded-md"
              />
            </div>

            {/* Limit Configuration Oversold */}
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-850 px-2.5 py-1 rounded-xl">
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-tight font-bold">RSI Bajo:</span>
              <input
                id="input-os-rsi"
                type="number"
                min="5"
                max="30"
                value={rsiOversold}
                onChange={(e) => setRsiOversold(Math.max(5, Math.min(30, parseInt(e.target.value) || 15)))}
                className="w-12 text-center bg-slate-950 border border-slate-800 text-emerald-400 font-extrabold font-mono text-xs p-0.5 rounded-md"
              />
            </div>

            {/* Timeframe selector buttons */}
            <div className="flex bg-slate-900 border border-slate-850 rounded-xl p-0.5">
              {(['5m', '15m', '1h', '4h'] as const).map((tf) => (
                <button
                  id={`btn-tf-${tf}`}
                  key={tf}
                  onClick={() => setActiveTimeframe(tf)}
                  className={`px-3 py-1 font-mono text-[11px] font-extrabold rounded-lg transition-all ${
                    activeTimeframe === tf
                      ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.6)]'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>

            {/* Active Running state indicators block */}
            <button
              id="btn-scan-loop-toggle"
              onClick={() => setIsScanning(!isScanning)}
              className={`px-3 py-1 border rounded-xl flex items-center gap-2 transition-all cursor-pointer font-mono text-[11px] font-bold leading-none ${
                isScanning
                  ? 'bg-emerald-950/45 border-emerald-800 text-emerald-400'
                  : 'bg-rose-955 border-rose-800 text-rose-400 shadow-[0_0_12px_rgba(244,63,94,0.2)]'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${isScanning ? 'bg-emerald-400 animate-ping shadow-[0_0_8px_#34d399]' : 'bg-rose-500'}`}></span>
              <span>{isScanning ? 'SCANNER COMPILANDO' : 'DETENIDO'}</span>
            </button>
          </div>

        </div>
      </header>

      {/* STATISTICS HEADER PANEL */}
      <section className="bg-slate-950/80 px-4 py-2 border-b border-slate-900/60 backdrop-blur-sm">
        <div className="max-w-full xl:px-4 mx-auto grid grid-cols-2 md:grid-cols-5 gap-3">
          
          <div className="bg-slate-900/35 border border-slate-900 p-2.5 rounded-xl flex flex-col justify-between shadow-md">
            <span className="text-[10px] uppercase font-mono text-slate-455 font-bold tracking-wider">CONTRATOS FILTRADOS</span>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-2xl font-black text-white">{tickerList.length}</span>
              <span className="text-[10px] font-mono text-emerald-400 font-bold">USDT</span>
            </div>
            <span className="text-[9px] font-mono text-slate-500 mt-0.5 uppercase">Binance + Bybit Futures</span>
          </div>

          <div className="bg-slate-900/35 border border-slate-900 p-2.5 rounded-xl flex flex-col justify-between shadow-md">
            <span className="text-[10px] uppercase font-mono text-slate-455 font-bold tracking-wider">SEÑALADOS EXTREMOS</span>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-2xl font-black text-cyan-405">{stats.activesSignalsCount}</span>
              <span className="text-[10px] font-mono text-slate-400">en {activeTimeframe}</span>
            </div>
            <span className="text-[9px] font-mono text-cyan-500 mt-0.5 uppercase">RSI Extremo detectado</span>
          </div>

          <div className="bg-slate-900/35 border border-slate-900 p-2.5 rounded-xl flex flex-col justify-between shadow-md">
            <span className="text-[10px] uppercase font-mono text-slate-455 font-bold tracking-wider">CONSENSO COMPRA/VENTA</span>
            <div className="flex items-center gap-2 mt-1.5">
              <div className="flex-1 bg-slate-800 h-2 rounded-full overflow-hidden flex border border-slate-900">
                <span className="bg-emerald-500 h-full" style={{ width: `${stats.longPct}%` }}></span>
                <span className="bg-rose-500 h-full" style={{ width: `${stats.shortPct}%` }}></span>
              </div>
            </div>
            <div className="flex justify-between items-center text-[9px] font-mono text-slate-350 mt-1 font-bold uppercase">
              <span className="text-emerald-450">COMPRA: {stats.longPct}%</span>
              <span className="text-rose-455">VENTA: {stats.shortPct}%</span>
            </div>
          </div>

          <div className="bg-slate-900/35 border border-slate-900 p-2.5 rounded-xl flex flex-col justify-between shadow-md">
            <span className="text-[10px] uppercase font-mono text-slate-455 font-bold tracking-wider">TOP MONEDAS SCORING</span>
            {stats.topAssets.length > 0 ? (
              <div className="flex flex-col gap-0.5 mt-0.5 info-block font-mono text-[9.5px]">
                {stats.topAssets.map((a) => (
                  <div key={a.symbol} className="flex justify-between items-center">
                    <span className="text-slate-200 font-extrabold">{a.symbol.replace('USDT', '')}</span>
                    <span className="text-amber-400 font-black">{a.score} PTS</span>
                  </div>
                ))}
              </div>
            ) : (
              <span className="text-[10px] text-slate-500 mt-1 font-mono">Construyendo rankings...</span>
            )}
          </div>

          <div className="bg-slate-900/35 border border-slate-900 p-2.5 rounded-xl flex flex-col justify-between shadow-md col-span-2 md:col-span-1">
            <span className="text-[10px] uppercase font-mono text-slate-455 font-bold tracking-wider text-right md:text-left">ESTADO DE API</span>
            <div className="flex items-baseline md:justify-start justify-end gap-1.5 mt-1">
              <span className={`w-2 h-2 rounded-full ${apiStatus === 'ONLINE' ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'}`}></span>
              <span className="text-xs font-black text-slate-100 uppercase tracking-wide">
                API DIRECTA
              </span>
            </div>
            <span className="text-[9px] font-mono text-slate-500 text-right md:text-left mt-0.5 uppercase">
              CONEXIÓN SSL MULTI-ORIGEN
            </span>
          </div>

        </div>
      </section>

      {/* CORE WORKSPACE GRID CONTAINER (12 col grid for wider opportunities layout) */}
      <main className="flex-1 max-w-full w-full mx-auto p-4 xl:px-6 grid grid-cols-1 xl:grid-cols-12 gap-4">

        {/* 1. LEFT SIDEBAR: ACTIVE FUTURES RANKING PANELS (Spans 3 Columns for wider chart and less clutter) */}
        <div className="xl:col-span-3 bg-slate-950/90 border border-slate-800 rounded-2xl p-3 backdrop-blur-md flex flex-col h-[490px] xl:h-[490px] shadow-2xl relative overflow-hidden">
          
          <div className="flex items-center justify-between border-b border-slate-950 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="text-cyan-400" size={17} />
              <span className="text-xs font-extrabold text-white uppercase tracking-wider">OPORTUNIDADES {searchQuery ? 'FILTRADAS' : 'EXTREMAS'}</span>
            </div>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-bold">RSI SCAN</span>
          </div>

          {/* Search box filters */}
          <div className="relative mb-4">
            <input
              id="search-ranking-input"
              type="text"
              placeholder="Filtro de símbolo (e.g., BTC)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-1 focus:ring-cyan-500 placeholder-slate-600 block"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-xs text-slate-550 hover:text-slate-205 font-sans font-extrabold cursor-pointer"
              >
                ✖
              </button>
            )}
          </div>

          {/* Ranking Cards Scroll list with prominent cards */}
          <div className="flex-grow overflow-y-auto pr-1 space-y-2 flex flex-col justify-start">
            {sortedRanking.length === 0 ? (
              <div className="flex-grow flex flex-col items-center justify-center text-center p-4 border border-dashed border-slate-800 rounded-2xl bg-slate-900/10 my-1 min-h-[300px]">
                <div className="p-2 bg-slate-900 rounded-full border border-slate-850 text-cyan-455 animate-pulse border-dashed mb-3">
                  <SlidersHorizontal size={20} />
                </div>
                <div className="text-xs font-black text-slate-300 uppercase tracking-wider">Sin extremos en este momento</div>
                <p className="text-[10px] font-mono leading-relaxed text-slate-500 max-w-[220px] mt-2 text-center">
                  Monitoreando {tickerList.length} monedas... Buscando RSI extremos (&le; {rsiOversold} o &ge; {rsiOverbought}) en tempo de {activeTimeframe}...
                </p>
                <p className="text-[9px] font-mono text-cyan-600/70 mt-3 uppercase tracking-widest font-bold">
                  Autoparlantes activos
                </p>
              </div>
            ) : (
              sortedRanking.map((asset) => {
                const isSelected = asset.symbol === activeSymbol;
                
                // Define warning RSI colors
                let rsiColorBadge = 'text-cyan-400 font-extrabold';
                if (asset.rsi >= rsiOverbought) rsiColorBadge = 'text-rose-400 font-black';
                else if (asset.rsi <= rsiOversold) rsiColorBadge = 'text-emerald-400 font-black';

                // Determine signal label and glow borders
                let borderClass = 'border-slate-900 hover:border-slate-800 hover:bg-slate-900/40';
                let signalLabel = 'neutral';
                
                if (asset.rsi >= rsiOverbought) {
                  borderClass = isSelected ? 'border-rose-500 bg-rose-950/20 shadow-[0_0_15px_rgba(244,63,94,0.2)]' : 'border-rose-950/80 bg-rose-950/5 hover:border-rose-800';
                  signalLabel = asset.rsi >= 90 ? 'SNIPER SHORT' : 'SHORT';
                } else if (asset.rsi <= rsiOversold) {
                  borderClass = isSelected ? 'border-emerald-500 bg-emerald-950/20 shadow-[0_0_15px_rgba(16,185,129,0.2)]' : 'border-emerald-950/80 bg-emerald-950/5 hover:border-emerald-800';
                  signalLabel = asset.rsi <= 10 ? 'SNIPER LONG' : 'LONG';
                } else if (isSelected) {
                  borderClass = 'border-cyan-500 bg-cyan-950/15 shadow-[0_0_12px_rgba(6,182,212,0.15)]';
                }

                return (
                  <button
                    id={`ranking-card-${asset.symbol}`}
                    key={asset.symbol}
                    onClick={() => setActiveSymbol(asset.symbol)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-left transition-all duration-300 relative overflow-hidden backdrop-blur-xs cursor-pointer ${borderClass}`}
                  >
                    {/* Glowing left highlight line under selection */}
                    {isSelected && (
                      <span className="absolute left-0 inset-y-0 w-[4px] bg-cyan-400"></span>
                    )}

                    <div className="flex flex-col gap-0.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-extrabold text-xs sm:text-xs text-white tracking-wide">
                          {asset.symbol.replace('USDT', '')}
                        </span>
                        {signalLabel !== 'neutral' && (
                          <span className={`text-[8px] font-mono px-1 py-0.2 rounded font-black tracking-tight uppercase ${
                            signalLabel.includes('SHORT') ? 'bg-rose-950 border border-rose-850 text-rose-400' : 'bg-emerald-950 border border-emerald-850 text-emerald-400'
                          }`}>
                            {signalLabel}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-slate-500 font-medium">
                        ${asset.price.toLocaleString(undefined, {
                          minimumFractionDigits: asset.price < 1 ? 4 : 2,
                          maximumFractionDigits: asset.price < 1 ? 6 : 2,
                        })}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Live indicator levels */}
                      <div className="flex flex-col items-end gap-0.5">
                        <div className="text-[10px] font-mono font-medium">
                          RSI <span className={rsiColorBadge}>{typeof asset.rsi === 'number' ? asset.rsi.toFixed(1) : '50.0'}</span>
                        </div>
                        <span className={`text-[10px] font-mono font-bold flex items-center gap-0.5 ${
                          asset.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(1)}%
                        </span>
                      </div>

                      {/* Circular structural Score card */}
                      <div className="flex flex-col items-center justify-center bg-slate-900 border border-slate-800 rounded-lg w-10 h-10 shrink-0">
                        <span className="text-[14px] font-black text-amber-400 font-mono">
                          {asset.score}
                        </span>
                        <span className="text-[7px] text-slate-550 font-mono tracking-tighter font-extrabold leading-none">SCORE</span>
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Sizing indicators label */}
          <div className="border-t border-slate-900 pt-3 mt-3 flex justify-between items-center text-[10px] font-mono text-slate-500 uppercase tracking-wide font-extrabold">
            <span>Frecuencia: ~{scanSpeed} calculos/min</span>
            <span>Binance Live TLS</span>
          </div>
        </div>

        {/* 2. MAIN CENTER: INTERACTIVE CANDLESTICK CHART (Spans 6 Columns for maximum room and legibility) */}
        <div className="xl:col-span-6 flex flex-col gap-4">
          <div className="flex-1 h-[490px] xl:h-[490px] bg-slate-950/80 border border-slate-800 rounded-2xl p-2 shadow-2xl overflow-hidden relative">
            <ScannerChart
              symbol={activeSymbol}
              candles={activeCandles}
              analysis={activeAnalysis || {
                rsi: [],
                ema50: [],
                ema200: [],
                supports: [],
                resistances: [],
                channelUpper: [],
                channelLower: [],
                marketStructure: [],
                trendLine: [],
                divergences: [],
                currentScore: 0,
                scoreBreakdown: { rsi: 0, divergence: 0, trend: 0, oi: 0, funding: 0, volume: 0, supRes: 0 },
                signals: [],
              }}
              timeframe={activeTimeframe}
            />
          </div>
        </div>

        {/* 3. RIGHT SIDEBAR: DETAILED STATS, SCORES & MTF CONSENSUS (Spans 3 Columns) */}
        <div className="xl:col-span-3 bg-slate-950/90 border border-slate-800 rounded-2xl p-3 backdrop-blur-md flex flex-col h-[490px] xl:h-[490px] shadow-2xl overflow-y-auto">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-950 pb-2 mb-2">
              <Layers className="text-cyan-400" size={15} />
              <span className="text-xs font-extrabold text-white uppercase tracking-widest">CONSENSO INSTITUCIONAL ({activeSymbol.replace('USDT', '')})</span>
            </div>

            {/* A. Consensus Multi-Timeframe Alignment */}
            <div className="p-2.5 bg-slate-900/55 border border-slate-850 rounded-xl mb-2 text-center shadow-inner">
              <span className="text-[9.5px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Consenso de Tendencia General</span>
              <div className={`mt-1.5 py-1 border rounded-lg text-xs font-black font-mono text-center tracking-widest ${consensusObj.color}`}>
                {consensusObj.label}
              </div>

              {/* Individual Timeframe status grid lines */}
              <div className="grid grid-cols-4 gap-1.5 mt-2.5 border-t border-slate-950/60 pt-2">
                {['5m', '15m', '1h', '4h'].map((tf) => {
                  const data = mtfData[tf];
                  const hasSignal = data && (data.rsi >= rsiOverbought || data.rsi <= rsiOversold);

                  return (
                    <div key={tf} className="flex flex-col gap-0.5 p-1 bg-slate-950/80 border border-slate-900 rounded-md">
                      <span className="text-[9px] text-slate-500 uppercase font-black">{tf}</span>
                      <span className="text-[11px] font-black text-slate-200 font-mono">
                        {data ? data.rsi.toFixed(1) : '50.0'}
                      </span>
                      <span className={`text-[7.5px] font-black py-0.2 px-0.1 rounded uppercase ${
                        data?.trend === 'Alcista' ? 'text-emerald-400' : data?.trend === 'Bajista' ? 'text-rose-400' : 'text-slate-500'
                      }`}>
                        {data ? (data.trend === 'Alcista' ? 'UP' : data.trend === 'Bajista' ? 'DOWN' : 'NEUTRAL') : '...'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* B. Dynamic Scoring breakdown progress bars (0-100) */}
            <div className="mb-2">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Distribución Score</span>
                <span className="text-[10px] font-mono text-amber-400 font-black">
                  {activeAnalysis ? activeAnalysis.currentScore : '0'}/100 PTS
                </span>
              </div>

              {/* Progress gauge chart */}
              <div className="space-y-1.5">
                {[
                  { label: 'RSI Extremo', score: activeAnalysis?.scoreBreakdown.rsi ?? 0, max: 25 },
                  { label: 'Divergencia Activa', score: activeAnalysis?.scoreBreakdown.divergence ?? 0, max: 20 },
                  { label: 'Tendencia EMA', score: activeAnalysis?.scoreBreakdown.trend ?? 0, max: 15 },
                  { label: 'Open Interest', score: activeAnalysis?.scoreBreakdown.oi ?? 0, max: 10 },
                  { label: 'Funding Rate', score: activeAnalysis?.scoreBreakdown.funding ?? 0, max: 10 },
                  { label: 'Volumen Com.', score: activeAnalysis?.scoreBreakdown.volume ?? 0, max: 10 },
                  { label: 'Soporte / Resist.', score: activeAnalysis?.scoreBreakdown.supRes ?? 0, max: 10 },
                ].map((row) => (
                  <div key={row.label} className="text-[9.5px] font-mono flex flex-col gap-0.5">
                    <div className="flex justify-between items-baseline font-bold">
                      <span className="text-slate-400 uppercase tracking-wide">{row.label}</span>
                      <span className="text-slate-254 font-black">{row.score}/{row.max}</span>
                    </div>
                    {/* Tiny custom styled bar */}
                    <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-850">
                      <div
                        className="bg-gradient-to-r from-cyan-400 to-cyan-500 h-full transition-all duration-500 shadow-[0_0_8px_rgba(6,182,212,0.5)]"
                        style={{ width: `${(row.score / row.max) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* C. Sniper alert state status blocks */}
            <div className="border-t border-slate-950 pt-3">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="text-yellow-405 shrink-0" size={14} />
                <span className="text-xs font-mono text-yellow-400 uppercase tracking-widest font-bold">SISTEMA SNIPER INTRAWAVE</span>
              </div>
              
              {activeAnalysis && (activeAnalysis.rsi[activeAnalysis.rsi.length - 1] <= 10 || activeAnalysis.rsi[activeAnalysis.rsi.length - 1] >= 90) ? (
                <div className="p-3 bg-yellow-950/20 border border-yellow-800/80 rounded-xl text-yellow-400 text-center font-mono text-xs font-black animate-pulse">
                  🎯 SNIPER DETECTADO: CONDICIÓN EXTREMA DE ENTRADA
                  <div className="text-[10px] text-slate-450 mt-1 uppercase font-semibold">
                    Involución de tendencia de máxima probabilidad alcista/bajista.
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-slate-900/35 border border-slate-850 rounded-xl text-slate-500 text-center font-mono text-xs font-extrabold uppercase">
                  Scanner Sniper en Standby • Evaluando RSI...
                </div>
              )}
            </div>

          </div>

          {/* D. Additional specifications labels list with larger font sizes */}
          <div className="border-t border-slate-900 pt-4 mt-4 text-[11px] font-mono space-y-2 uppercase tracking-wide font-extrabold">
            <div className="flex justify-between items-baseline">
              <span className="text-slate-550">TASA FINANCIERA (FUNDING):</span>
              <span className={`font-black ${
                (tickerList.find((t) => t.symbol === activeSymbol)?.fundingRate || 0) >= 0.0003 ? 'text-rose-400' : 'text-emerald-400'
              }`}>
                {((tickerList.find((t) => t.symbol === activeSymbol)?.fundingRate || 0.0001) * 100).toFixed(4)}%
              </span>
            </div>
            
            <div className="flex justify-between items-baseline">
              <span className="text-slate-550">OPEN INTEREST ESTIMADO:</span>
              <span className="text-slate-200 font-extrabold">
                ${((tickerList.find((t) => t.symbol === activeSymbol)?.openInterest || 5000000)).toLocaleString(undefined, { maximumFractionDigits: 0 })} USDT
              </span>
            </div>

            <div className="flex justify-between items-baseline">
              <span className="text-slate-550">SOPORTES DETECTADOS:</span>
              <span className="text-emerald-450 font-black truncate max-w-[140px] tracking-tighter">
                {activeAnalysis ? activeAnalysis.supports.map((s) => s.toFixed(2)).join(' | ') : '...'}
              </span>
            </div>

            <div className="flex justify-between items-baseline">
              <span className="text-slate-550">RESISTENCIAS DETECTADAS:</span>
              <span className="text-rose-455 font-black truncate max-w-[140px] tracking-tighter">
                {activeAnalysis ? activeAnalysis.resistances.map((r) => r.toFixed(2)).join(' | ') : '...'}
              </span>
            </div>
          </div>
        </div>

      </main>

      {/* FOOTER HISTORIC TIMELINE PANEL */}
      <section className="max-w-[1550px] w-full mx-auto px-4 pb-8">
        <AlertsPanel
          alerts={alerts}
          onClear={() => setAlerts([])}
          onSelectSymbol={(s) => setActiveSymbol(s)}
          activeSymbol={activeSymbol}
          activeRsi={
            activeAnalysis 
              ? activeAnalysis.rsi[activeAnalysis.rsi.length - 1] 
              : (assets[activeSymbol]?.rsi ?? 50)
          }
        />
      </section>

      {/* Cyberpunk Footer credentials */}
      <footer className="border-t border-slate-900 bg-slate-950 py-5 text-center text-xs font-mono text-slate-650 font-bold uppercase tracking-widest">
        <div className="max-w-[1550px] mx-auto flex flex-col sm:flex-row justify-between items-center px-4 gap-2">
          <span>© CALCULADORA CLIENTE 100% EXCLUSIVE • CONTROLES QUANT ACTIVADOS</span>
          <span className="text-cyan-805">CONSTRUCCIÓN COMPLETA DE ALINEACIONES MULTI-TIMEFRAME</span>
        </div>
      </footer>

    </div>
  );
}
