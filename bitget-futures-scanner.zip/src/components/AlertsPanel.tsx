/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { Bell, Volume2, ShieldAlert, Award, VolumeX, Copy, Trash2, CheckCircle2 } from 'lucide-react';

export interface AlertEntry {
  id: string;
  time: number;
  symbol: string;
  price: number;
  rsi: number;
  score: number;
  type: 'LONG' | 'SHORT' | 'SNIPER_LONG' | 'SNIPER_SHORT';
  msg: string;
}

// Custom Web Audio Synthesizer
class SoundEngine {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  constructor() {
    if (typeof window !== 'undefined') {
      const resume = () => {
        this.resume();
        window.removeEventListener('click', resume);
        window.removeEventListener('keydown', resume);
      };
      window.addEventListener('click', resume);
      window.addEventListener('keydown', resume);
    }
  }

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch((e) => console.warn('Failed to resume sound context', e));
    }
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch((e) => console.warn('Failed to resume sound context on action', e));
    }
  }

  playSuave() {
    try {
      if (!this.enabled) return;
      this.initCtx();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'sine'; // very soft and warm
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880.00, now + 0.3); // A5
      
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.2, now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.6);
    } catch (e) {
      console.warn('Audio Synthesis failed', e);
    }
  }

  playFuerte() {
    try {
      if (!this.enabled) return;
      this.initCtx();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      
      // Dual beep for warning attention block
      [0, 0.18].forEach((delay) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        
        osc.type = 'triangle'; // brighter, alert style
        osc.frequency.setValueAtTime(1200.00, now + delay); // C6-ish
        
        gain.gain.setValueAtTime(0, now + delay);
        gain.gain.linearRampToValueAtTime(0.35, now + delay + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.16);
        
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        osc.start(now + delay);
        osc.stop(now + delay + 0.2);
      });
    } catch (e) {
      console.warn('Audio Synthesis failed', e);
    }
  }

  playCritica() {
    try {
      if (!this.enabled) return;
      this.initCtx();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      
      // Triple alarming high-pitch pulse
      [0, 0.15, 0.3].forEach((delay, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        
        osc.type = 'sawtooth'; // piercing high-attention
        osc.frequency.setValueAtTime(1500.00 - idx * 100, now + delay);
        
        gain.gain.setValueAtTime(0, now + delay);
        gain.gain.linearRampToValueAtTime(0.4, now + delay + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.12);
        
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        osc.start(now + delay);
        osc.stop(now + delay + 0.15);
      });
    } catch (e) {
      console.warn('Audio Synthesis failed', e);
    }
  }
}

export const synths = new SoundEngine();

interface AlertsPanelProps {
  alerts: AlertEntry[];
  onClear: () => void;
  onSelectSymbol: (symbol: string) => void;
  activeSymbol: string;
  activeRsi: number;
}

export default function AlertsPanel({ 
  alerts, 
  onClear, 
  onSelectSymbol, 
  activeSymbol, 
  activeRsi 
}: AlertsPanelProps) {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>('default');

  const [breathCount, setBreathCount] = useState(0);

  useEffect(() => {
    synths.enabled = soundEnabled;
  }, [soundEnabled]);

  useEffect(() => {
    if ('Notification' in window) {
      setNotifPermission(Notification.permission);
    }
  }, []);

  // Periodic breathing animation to make the SVG cloud feel like an alive, floating vapor
  useEffect(() => {
    const interval = setInterval(() => {
      setBreathCount((prev) => (prev + 1) % 100);
    }, 2800);
    return () => clearInterval(interval);
  }, []);

  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) return;
    try {
      const resp = await Notification.requestPermission();
      setNotifPermission(resp);
    } catch (err) {
      console.error('No se pudieron obtener permisos de notificación', err);
    }
  };

  const handleTestAlert = (type: 'suave' | 'fuerte' | 'critica') => {
    if (!soundEnabled) return;
    if (type === 'suave') synths.playSuave();
    if (type === 'fuerte') synths.playFuerte();
    if (type === 'critica') synths.playCritica();
  };

  // Compute color, cloud color, and status description
  const mainVal = Math.round(activeRsi);
  let color = '#ffaa00'; // neutral
  let cloudColor = 'rgba(255, 170, 0, 0.22)';
  let statusText = 'MERCADO NEUTRAL';

  if (mainVal > 55) {
    color = '#00ff88'; // Buyers dominate
    cloudColor = 'rgba(0, 255, 136, 0.22)';
    statusText = 'COMPRADORES DOMINAN';
  } else if (mainVal < 45) {
    color = '#ff3b3b'; // Sellers dominate
    cloudColor = 'rgba(255, 59, 59, 0.22)';
    statusText = 'VENDEDORES DOMINAN';
  }

  // Soft organic procedural cloud path Generator
  const generateCloudPath = (val: number) => {
    const puntos = 7;
    const ancho = 320;
    const base = 48;
    // Amplitude scales with how extreme the market momentum is
    const amp = (Math.abs(val - 50) / 50) * 18 + 7;

    let pts = [];
    const hash = activeSymbol.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) + breathCount;
    let s = hash;
    const randomSeed = () => {
      const x = Math.sin(s++) * 10000;
      return x - Math.floor(x);
    };

    for (let i = 0; i <= puntos; i++) {
      let x = (i / puntos) * ancho;
      let y = base - randomSeed() * amp;
      pts.push({ x, y });
    }

    let d = `M0,60 L0,${pts[0].y.toFixed(1)} `;
    for (let i = 0; i < pts.length - 1; i++) {
      let p = pts[i];
      let n = pts[i + 1];
      let cx = (p.x + n.x) / 2;
      d += `Q${p.x.toFixed(1)},${p.y.toFixed(1)} ${cx.toFixed(1)},${((p.y + n.y) / 2).toFixed(1)} `;
    }

    let last = pts[pts.length - 1];
    d += `Q${last.x.toFixed(1)},${last.y.toFixed(1)} ${ancho},48 L${ancho},60 Z`;
    return d;
  };

  const cloudD = generateCloudPath(mainVal);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">
      {/* 1. Control Settings Left */}
      <div className="md:col-span-1 lg:col-span-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-md flex flex-col justify-between shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Bell className="text-cyan-400" size={16} />
            <span className="text-xs font-extrabold text-white tracking-wider">ENTORNO DE ALERTAS</span>
          </div>
          <p className="text-slate-400 text-[10.5px] font-sans leading-relaxed mb-3">
            Configure alertas auditivas sintéticas e integre notificaciones nativas del sistema para operar en segundo plano.
          </p>

          <div className="space-y-2.5">
            {/* Audio Toggle */}
            <div className="flex items-center justify-between p-2.5 bg-slate-900/60 border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-300 font-medium">Bocinas Sintética</span>
              <button
                id="btn-toggle-sound"
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`p-1.5 rounded-lg border transition-all ${
                  soundEnabled
                    ? 'bg-emerald-950/30 border-emerald-800/80 text-emerald-400'
                    : 'bg-rose-955/30 border-rose-800/80 text-rose-500'
                }`}
                title="Habilitar/Deshabilitar Alertas de Sonido"
              >
                {soundEnabled ? <Volume2 size={13} /> : <VolumeX size={13} />}
              </button>
            </div>

            {/* Notification Permission Toggle */}
            <div className="flex flex-col gap-1.5 p-2.5 bg-slate-900/60 border border-slate-800 rounded-xl">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-300 font-medium">Notificación Push</span>
                <span className={`text-[8.5px] font-mono px-1.5 py-0.2 rounded ${
                  notifPermission === 'granted' ? 'bg-emerald-900/30 text-emerald-400' : 'bg-slate-800 text-slate-400'
                }`}>
                  {notifPermission === 'granted' ? 'ACTIVA' : 'INACTIVA'}
                </span>
              </div>
              {notifPermission !== 'granted' && (
                <button
                  id="btn-notif-grant"
                  onClick={requestNotificationPermission}
                  className="w-full py-0.5 text-[9px] bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-800 hover:border-cyan-600 text-cyan-300 transition-all rounded-md font-mono"
                >
                  CONCEDER PERMISOS
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Audio testing console */}
        <div className="border-t border-slate-900/60 pt-3 mt-3">
          <span className="text-[9.5px] font-mono text-slate-500 uppercase tracking-widest block mb-1.5">PROBAR SINTETIZADOR</span>
          <div className="grid grid-cols-3 gap-1">
            <button
              id="btn-test-sound-suave"
              onClick={() => handleTestAlert('suave')}
              className="py-0.5 px-1 text-[9px] bg-slate-900 border border-slate-800 hover:border-slate-700 text-emerald-400 rounded transition-all font-mono text-center hover:bg-emerald-950/10"
            >
              Suave
            </button>
            <button
              id="btn-test-sound-fuerte"
              onClick={() => handleTestAlert('fuerte')}
              className="py-0.5 px-1 text-[9px] bg-slate-900 border border-slate-800 hover:border-slate-700 text-rose-400 rounded transition-all font-mono text-center hover:bg-rose-955/10"
            >
              Fuerte
            </button>
            <button
              id="btn-test-sound-critica"
              onClick={() => handleTestAlert('critica')}
              className="py-0.5 px-1 text-[9px] bg-slate-900 border border-slate-800 hover:border-slate-700 text-purple-400 rounded transition-all font-mono text-center hover:bg-purple-955/10"
            >
              Crítica
            </button>
          </div>
        </div>
      </div>

      {/* 2. Historic Timeline Table Center (lg:col-span-6 for balanced spacing) */}
      <div className="md:col-span-1 lg:col-span-6 bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-md flex flex-col justify-between min-h-[220px] shadow-xl">
        <div>
          <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className="text-cyan-400" size={15} />
              <span className="text-xs font-extrabold text-white tracking-wider uppercase">REGISTRO HISTÓRICO DE AUDITORÍA</span>
            </div>
            {alerts.length > 0 && (
              <button
                id="btn-clear-alerts"
                onClick={onClear}
                className="p-0.5 px-1.5 bg-rose-955 border border-rose-900/60 text-[9px] text-rose-400 rounded hover:bg-rose-900/30 transition-all font-mono flex items-center gap-1 cursor-pointer"
              >
                <Trash2 size={10} />
                <span>LIMPIAR LOG</span>
              </button>
            )}
          </div>

          <div className="max-h-[145px] overflow-y-auto pr-1">
            {alerts.length === 0 ? (
              <div className="h-24 flex flex-col items-center justify-center text-slate-500 font-mono gap-0.5 text-xs text-center py-4">
                <CheckCircle2 className="text-cyan-900" size={16} />
                <span className="text-[10.5px]">Escaneando el mercado... Sin alertas disparadas en la sesión actual.</span>
                <span className="text-[9px] text-slate-655 mt-0.5">
                  (Las alertas se disparan y suenan cuando el RSI rompe {`<= 15`} o {`>= 85`})
                </span>
              </div>
            ) : (
              <table className="w-full text-left text-[10.5px] text-slate-300 font-mono">
                <thead>
                  <tr className="border-b border-slate-900 text-slate-500 text-[9.5px]">
                    <th className="py-1">HORA</th>
                    <th>PAR</th>
                    <th>VALOR RSI</th>
                    <th>PUNTAJE (SCORE)</th>
                    <th>ALERTA</th>
                    <th>ACCIONES</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900/40">
                  {alerts.map((entry) => {
                    // Type color
                    let typeBadge = '';
                    if (entry.type.includes('SNIPER')) {
                      typeBadge = entry.type.includes('LONG') 
                         ? 'bg-emerald-950 border-emerald-500/80 text-emerald-400 font-bold'
                        : 'bg-rose-955 border-rose-500/80 text-rose-400 font-bold';
                    } else {
                      typeBadge = entry.type.includes('LONG')
                        ? 'bg-emerald-950/45 border-emerald-800 text-emerald-400'
                        : 'bg-rose-950/45 border-rose-800 text-rose-400';
                    }

                    return (
                      <tr key={entry.id} className="hover:bg-slate-900/35 transition-colors">
                        <td className="py-1 text-slate-454 text-[10px]">
                          {new Date(entry.time).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </td>
                        <td className="font-bold text-white tracking-wide text-[10px]">
                          {entry.symbol}
                        </td>
                        <td>
                          <span className={`text-[10px] ${entry.rsi >= 80 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}`}>
                            {entry.rsi.toFixed(1)}
                          </span>
                        </td>
                        <td className="text-amber-400 font-bold text-center text-[10px]">
                          {entry.score}/100
                        </td>
                        <td>
                          <span className={`px-1.5 py-0.2 rounded border text-[8px] ${typeBadge}`}>
                            {entry.msg}
                          </span>
                        </td>
                        <td>
                          <div className="flex items-center gap-1 py-0.5">
                            <button
                              id={`btn-jump-alert-${entry.symbol}`}
                              onClick={() => onSelectSymbol(entry.symbol)}
                              className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-400 hover:text-cyan-300 py-0.2 px-1 rounded text-[9.5px] transition-all cursor-pointer font-mono"
                              title="Inspeccionar en Gráfico de Scanner"
                            >
                              Ver
                            </button>
                            <a
                              id={`lnk-bitget-alert-${entry.symbol}`}
                              href={`https://www.bitget.com/es/mix/usdt/${entry.symbol}_UMCBL`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-emerald-950/45 hover:bg-emerald-900/40 border border-emerald-850 text-emerald-400 hover:text-emerald-300 py-0.2 px-1 rounded text-[9.5px] transition-all cursor-pointer font-mono font-bold"
                              title="Abrir posición comercial directa en Bitget"
                            >
                              Ir a gráfico ↗
                            </a>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div className="flex justify-between items-center text-[9px] text-slate-600 font-mono mt-2 border-t border-slate-950/60 pt-1.5">
          <span>* Almacenamiento local temporal en RAM por pestaña abierta.</span>
          <span className="flex items-center gap-1 text-cyan-900">
            <Award size={9} /> INSTITUTIONAL DETECTOR GATE v1.29
          </span>
        </div>
      </div>

      {/* 3. Market Dominance Card (lg:col-span-3 for a balanced 3-palette layout) */}
      <div className="md:col-span-1 lg:col-span-3 bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-md flex flex-col justify-between min-h-[220px] shadow-xl relative overflow-hidden">
        
        {/* Title */}
        <div className="text-[10px] text-center text-slate-400 font-black font-mono tracking-widest uppercase mb-1">
          DOMINANCIA DEL MERCADO ({activeSymbol.replace('USDT', '')})
        </div>

        {/* NUBE ENCIMA */}
        <div className="w-full h-[65px] my-1 overflow-hidden flex items-center justify-center relative">
          <svg viewBox="0 0 320 65" className="w-full h-full">
            <path
              d={cloudD}
              fill={cloudColor}
              className="transition-all duration-[1200ms] ease-in-out blur-[0.5px]"
            />
          </svg>
        </div>

        {/* BARRA */}
        <div className="w-full h-[18px] bg-slate-900 border border-slate-850 rounded-full relative overflow-hidden mt-1 shadow-inner">
          <div
            className="h-full rounded-full transition-all duration-[800ms] ease-out"
            style={{
              width: `${mainVal}%`,
              backgroundColor: color,
              boxShadow: `0 0 15px ${color}`,
            }}
          />
        </div>

        {/* INFO */}
        <div className="flex justify-between text-xs font-mono font-bold text-slate-350 mt-3 px-1 uppercase tracking-wide">
          <span style={{ color: mainVal > 50 ? color : undefined }}>{mainVal}% Compradores</span>
          <span style={{ color: mainVal < 50 ? color : undefined }}>{(100 - mainVal)}% Vendedores</span>
        </div>

        {/* ESTADO */}
        <div
          className="text-sm font-black font-mono tracking-widest text-center mt-2.5 transition-all duration-300"
          style={{ color }}
        >
          {statusText}
        </div>
      </div>

    </div>
  );
}
