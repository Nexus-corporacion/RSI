import React, { useEffect, useRef, useState } from 'react';
import { Candle, IndicatorResult } from '../utils/indicators';

interface ScannerChartProps {
  symbol: string;
  candles: Candle[];
  analysis: IndicatorResult;
  timeframe: '5m' | '15m' | '1h' | '4h';
}

declare global {
  interface Window {
    TradingView: any;
  }
}

export default function ScannerChart({ symbol, timeframe }: ScannerChartProps) {
  // Convert timeframe to TradingView compatible interval string
  const intervalStr = timeframe === '5m' ? '5' : timeframe === '15m' ? '15' : timeframe === '1h' ? '60' : '240';
  
  // Format the symbol. Our symbols are like "BTCUSDT".
  const chartSymbol = `BINANCE:${symbol.toUpperCase()}`;

  // Direct widget URL using fully robust embed structure
  const iframeUrl = `https://s.tradingview.com/widgetembed/?symbol=${chartSymbol}&interval=${intervalStr}&theme=dark&style=1&timezone=Etc%2FUTC&locale=es`;

  return (
    <div className="flex flex-col h-full bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden relative shadow-inner">
      {/* Dynamic Header Badge informing the user */}
      <div className="flex items-center justify-between p-3.5 bg-slate-900/60 border-b border-slate-800/80 font-mono">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-white font-extrabold text-sm tracking-wide">{symbol}</span>
          <span className="text-[10px] text-slate-500 font-bold uppercase py-0.5 px-2 bg-slate-950 border border-slate-800 rounded-md">
            Temporalidad: {timeframe}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-cyan-400 font-black tracking-wider uppercase border border-cyan-900/50 bg-cyan-950/40 px-2 py-0.5 rounded">
            PINE SCRIPT: SUPERTREND & EMA
          </span>
        </div>
      </div>

      {/* Main Chart Iframe Host Container */}
      <div className="flex-1 w-full bg-slate-950 min-h-[300px] relative">
        <iframe
          id="tv-widget-iframe"
          title={`TradingView Chart for ${symbol}`}
          src={iframeUrl}
          className="w-full h-full border-0 absolute inset-0"
          allowFullScreen
        />
      </div>

      <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono bg-slate-900/40 border-t border-slate-900 px-3.5 py-2">
        <span>* Gráfico interactivo en vivo con Línea de Tendencia Estructural (Supertrend), EMA y RSI activo.</span>
        <span className="text-[9px] text-cyan-700/80 font-bold uppercase tracking-widest">SOPORTE MULTI-INDICADORES</span>
      </div>
    </div>
  );
}
