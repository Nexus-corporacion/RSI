/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Candle {
  time: number; // timestamp in ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
}

export interface IndicatorResult {
  rsi: number[];
  ema50: number[];
  ema200: number[];
  supports: number[]; // Unique horizontal support prices
  resistances: number[]; // Unique horizontal resistance prices
  channelUpper: number[];
  channelLower: number[];
  marketStructure: {
    index: number;
    type: 'HH' | 'HL' | 'LH' | 'LL';
    price: number;
  }[];
  trendLine: {
    price: number;
    isBullish: boolean;
    state: 'bullish' | 'bearish' | 'neutral';
  }[];
  divergences: {
    index: number;
    type: 'bullish' | 'bearish';
    text: string;
  }[];
  currentScore: number;
  scoreBreakdown: {
    rsi: number;
    divergence: number;
    trend: number;
    oi: number;
    funding: number;
    volume: number;
    supRes: number;
  };
  signals: string[];
}

/**
 * Calculates EMA of a series
 */
export function calculateEMA(data: number[], period: number): number[] {
  const ema: number[] = new Array(data.length).fill(0);
  if (data.length === 0) return ema;

  const k = 2 / (period + 1);
  // Simple moving average for the first value
  let sum = 0;
  const initPeriod = Math.min(period, data.length);
  for (let i = 0; i < initPeriod; i++) {
    sum += data[i];
  }
  let prevEma = sum / initPeriod;
  ema[initPeriod - 1] = prevEma;

  for (let i = initPeriod; i < data.length; i++) {
    const currentEma = data[i] * k + prevEma * (1 - k);
    ema[i] = currentEma;
    prevEma = currentEma;
  }

  // Pre-fill initial values with first calculated EMA for visual continuity
  for (let i = 0; i < initPeriod - 1; i++) {
    ema[i] = ema[initPeriod - 1];
  }

  return ema;
}

/**
 * Calculates RSI of a series (Smoothed / Wilder's MA method)
 */
export function calculateRSI(closes: number[], period: number = 14): number[] {
  const rsi: number[] = new Array(closes.length).fill(50);
  if (closes.length <= period) return rsi;

  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    gains.push(diff > 0 ? diff : 0);
    losses.push(diff < 0 ? -diff : 0);
  }

  // Calculate first average gain/loss
  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 0; i < period; i++) {
    avgGain += gains[i];
    avgLoss += losses[i];
  }
  avgGain /= period;
  avgLoss /= period;

  rsi[period] = avgLoss === 0 ? 100 : avgGain === 0 ? 0 : 100 - 100 / (1 + avgGain / avgLoss);

  for (let i = period + 1; i < closes.length; i++) {
    const g = gains[i - 1];
    const l = losses[i - 1];

    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;

    rsi[i] = avgLoss === 0 ? 100 : avgGain === 0 ? 0 : 100 - 100 / (1 + avgGain / avgLoss);
  }

  // Pre-populate initial values
  for (let i = 0; i < period; i++) {
    rsi[i] = rsi[period];
  }

  return rsi;
}

/**
 * Advanced institutional analysis of market data
 */
export function analyzeIndicators(
  candles: Candle[],
  rsiOverbought: number = 85,
  rsiOversold: number = 15,
  options: { fundingRate?: number; openInterestChange?: number } = {}
): IndicatorResult {
  const result: IndicatorResult = {
    rsi: [],
    ema50: [],
    ema200: [],
    supports: [],
    resistances: [],
    channelUpper: [],
    channelLower: [],
    marketStructure: [],
    trendLine: [],
    divergences: [],
    currentScore: 0,
    scoreBreakdown: { rsi: 0, divergence: 0, trend: 0, oi: 0, funding: 0, volume: 0, supRes: 0 },
    signals: [],
  };

  const len = candles.length;
  if (len < 5) return result;

  const closes = candles.map((c) => c.close);
  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);

  // 1. Calculate RSI & EMAs
  result.rsi = calculateRSI(closes, 14);
  result.ema50 = calculateEMA(closes, 50);
  result.ema200 = calculateEMA(closes, 200);

  // 2. Channels (Donchian / Bollinger-like Price Channels for structural bounds)
  const channelPeriod = 20;
  result.channelUpper = new Array(len).fill(0);
  result.channelLower = new Array(len).fill(0);

  for (let i = 0; i < len; i++) {
    const start = Math.max(0, i - channelPeriod + 1);
    const windowHighs = highs.slice(start, i + 1);
    const windowLows = lows.slice(start, i + 1);
    result.channelUpper[i] = Math.max(...windowHighs);
    result.channelLower[i] = Math.min(...windowLows);
  }

  // 3. Support & Resistance Pivots
  // A pivot is local min/max over 5 candles (left 2, right 2)
  const pS: number[] = [];
  const pR: number[] = [];

  for (let i = 2; i < len - 2; i++) {
    const h = highs[i];
    const l = lows[i];

    // Pivot High (Resistance candidate)
    if (h > highs[i - 1] && h > highs[i - 2] && h > highs[i + 1] && h > highs[i + 2]) {
      pR.push(h);
    }
    // Pivot Low (Support candidate)
    if (l < lows[i - 1] && l < lows[i - 2] && l < lows[i + 1] && l < lows[i + 2]) {
      pS.push(l);
    }
  }

  // Cluster or pick distinct levels
  const uniqueRound = (arr: number[]) => {
    const sorted = [...arr].sort((a, b) => a - b);
    const filtered: number[] = [];
    for (const val of sorted) {
      if (filtered.length === 0 || val - filtered[filtered.length - 1] > val * 0.005) {
        filtered.push(val);
      }
    }
    return filtered.slice(-4); // keep latest 4 zones
  };

  result.supports = uniqueRound(pS);
  result.resistances = uniqueRound(pR);

  // 4. Market Structure (HH, HL, LH, LL)
  // Walk through pivot points and record their relationships
  let lastPivotHigh = 0;
  let lastPivotLow = 0;

  for (let i = 2; i < len - 2; i++) {
    const h = highs[i];
    const l = lows[i];

    // Pivot High
    if (h > highs[i - 1] && h > highs[i - 2] && h > highs[i + 1] && h > highs[i + 2]) {
      if (lastPivotHigh !== 0) {
        const type = h > lastPivotHigh ? 'HH' : 'LH';
        result.marketStructure.push({ index: i, type, price: h });
      }
      lastPivotHigh = h;
    }

    // Pivot Low
    if (l < lows[i - 1] && l < lows[i - 2] && l < lows[i + 1] && l < lows[i + 2]) {
      if (lastPivotLow !== 0) {
        const type = l > lastPivotLow ? 'HL' : 'LL';
        result.marketStructure.push({ index: i, type, price: l });
      }
      lastPivotLow = l;
    }
  }

  // 5. Intelligent EMA-based Trend Line (calculated exactly)
  // The EMA 50 acts as the trend line.
  // - Green (Bullish): Price is above EMA-50 AND (either RSI > 51, or recent bullish divergence)
  // - Red (Bearish): Price is below EMA-50 AND (either RSI < 49, or recent bearish divergence)
  // - Grey (Neutral / No Position): Price is consolidating around EMA (within 0.25% distance) or RSI is around 50 without divergence
  result.trendLine = new Array(len).fill(null).map((_, i) => {
    const emaVal = result.ema50[i] || closes[i];
    const rsiVal = result.rsi[i] || 50;
    const closeVal = closes[i];
    
    // Proximity to EMA to filter out noise
    const distPct = Math.abs(closeVal - emaVal) / emaVal;
    
    // Find active local divergence (within last 15 candles)
    const hasBullishDiv = result.divergences.some(d => i - d.index >= 0 && i - d.index < 15 && d.type === 'bullish');
    const hasBearishDiv = result.divergences.some(d => i - d.index >= 0 && i - d.index < 15 && d.type === 'bearish');

    let state: 'bullish' | 'bearish' | 'neutral' = 'neutral';
    
    if (distPct < 0.0025) {
      state = 'neutral';
    } else if (closeVal > emaVal) {
      if (rsiVal > 51 || hasBullishDiv || rsiVal < 30) {
        state = 'bullish';
      } else {
        state = 'neutral';
      }
    } else {
      if (rsiVal < 49 || hasBearishDiv || rsiVal > 70) {
        state = 'bearish';
      } else {
        state = 'neutral';
      }
    }

    return {
      price: emaVal,
      isBullish: state === 'bullish',
      state
    };
  });

  // 6. Divergences detection
  // Bullish: Price Lower Low, RSI Higher Low
  // Bearish: Price Higher High, RSI Lower High
  const msPoints = result.marketStructure;
  for (let j = 2; j < msPoints.length; j++) {
    const p1 = msPoints[j - 2];
    const p2 = msPoints[j];

    if (p1.type === 'LL' && p2.type === 'LL' && p2.index - p1.index < 35) {
      if (result.rsi[p2.index] > result.rsi[p1.index] + 1) {
        result.divergences.push({
          index: p2.index,
          type: 'bullish',
          text: 'Divergencia Alcista RSI',
        });
      }
    }
    if (p1.type === 'HH' && p2.type === 'HH' && p2.index - p1.index < 35) {
      if (result.rsi[p2.index] < result.rsi[p1.index] - 1) {
        result.divergences.push({
          index: p2.index,
          type: 'bearish',
          text: 'Divergencia Bajista RSI',
        });
      }
    }
  }

  // 7. Core scoring calculation (summing up to 100)
  const currentPrice = closes[len - 1];
  const currentRsi = result.rsi[len - 1];
  const latestTrend = result.trendLine[len - 1].isBullish;

  // Key scoring signals
  // A. RSI bounds (= 25 pts max)
  let rsiScore = 0;
  if (currentRsi <= rsiOversold) {
    rsiScore = 25;
    result.signals.push(`Oversold RSI (${currentRsi.toFixed(1)})`);
  } else if (currentRsi >= rsiOverbought) {
    rsiScore = 25;
    result.signals.push(`Overbought RSI (${currentRsi.toFixed(1)})`);
  } else {
    // Proximity scaling
    const distToExtreme = Math.min(
      Math.abs(currentRsi - rsiOversold),
      Math.abs(currentRsi - rsiOverbought)
    );
    if (distToExtreme < 10) {
      rsiScore = Math.floor((10 - distToExtreme) * 2.5); // scaling up to 25 pts
    }
  }
  result.scoreBreakdown.rsi = rsiScore;

  // B. Divergence active locally within recent 10 candles (= 20 pts max)
  const recentDivergence = result.divergences.find((d) => len - 1 - d.index < 12);
  let divScore = 0;
  if (recentDivergence) {
    divScore = 20;
    result.signals.push(`Divergencia Detectada (${recentDivergence.type === 'bullish' ? 'LONG' : 'SHORT'})`);
  }
  result.scoreBreakdown.divergence = divScore;

  // C. Trend align over EMAs (= 15 pts max)
  let trendScore = 0;
  const isEmaBullish = result.ema50[len - 1] > result.ema200[len - 1];
  // Align bullish candle trend with EMAs
  if (latestTrend === isEmaBullish) {
    trendScore = 15;
  } else {
    trendScore = 5;
  }
  result.scoreBreakdown.trend = trendScore;

  // D. Open Interest Change (= 10 pts max)
  let oiScore = 0;
  const oiC = options.openInterestChange ?? 0.05; // default positive change mock
  if (Math.abs(oiC) >= 0.03) {
    oiScore = 10;
    result.signals.push(`Open Interest Elevado (${(oiC * 100).toFixed(1)}%)`);
  } else {
    oiScore = Math.floor(Math.abs(oiC) * 330); // scale
  }
  result.scoreBreakdown.oi = Math.min(10, oiScore);

  // E. Funding Rate extremes (= 10 pts max)
  // Extreme high/low funding rate suggests reversal or excessive leverage
  let fScore = 0;
  const fRate = options.fundingRate ?? 0.0001;
  const absFr = Math.abs(fRate);
  if (absFr >= 0.0003) {
    fScore = 10;
    result.signals.push(`Funding Rate Extremo (${(fRate * 100).toFixed(4)}%)`);
  } else if (absFr >= 0.0001) {
    fScore = 6;
  } else {
    fScore = 3;
  }
  result.scoreBreakdown.funding = fScore;

  // F. Volume surge (= 10 pts max)
  let volScore = 0;
  const currentVol = candles[len - 1].volume;
  // Avg volume of last 20 candles
  const vols = candles.slice(-20).map((c) => c.volume);
  const avgVol = vols.reduce((sum, v) => sum + v, 0) / vols.length;
  if (currentVol > avgVol * 1.8) {
    volScore = 10;
    result.signals.push('Pico de Volumen Comercial');
  } else if (currentVol > avgVol * 1.2) {
    volScore = 6;
  } else {
    volScore = 2;
  }
  result.scoreBreakdown.volume = volScore;

  // G. Support & Resistance touches (= 10 pts max)
  let srScore = 0;
  const touchesSupport = result.supports.some((s) => Math.abs(currentPrice - s) / s < 0.003);
  const touchesResistance = result.resistances.some((r) => Math.abs(currentPrice - r) / r < 0.003);
  if (touchesSupport || touchesResistance) {
    srScore = 10;
    result.signals.push(`Toque de Zona Intradía (${touchesSupport ? 'Soporte' : 'Resistencia'})`);
  } else {
    // Proximity
    const minDistSup = Math.min(...result.supports.map((s) => Math.abs(currentPrice - s) / s));
    const minDistRes = Math.min(...result.resistances.map((r) => Math.abs(currentPrice - r) / r));
    const finalMinDist = Math.min(minDistSup, minDistRes);
    if (finalMinDist < 0.01) {
      srScore = Math.floor((0.01 - finalMinDist) * 1000);
    }
  }
  result.scoreBreakdown.supRes = Math.min(10, srScore);

  // Compute final aggregate Score
  result.currentScore =
    result.scoreBreakdown.rsi +
    result.scoreBreakdown.divergence +
    result.scoreBreakdown.trend +
    result.scoreBreakdown.oi +
    result.scoreBreakdown.funding +
    result.scoreBreakdown.volume +
    result.scoreBreakdown.supRes;

  return result;
}
